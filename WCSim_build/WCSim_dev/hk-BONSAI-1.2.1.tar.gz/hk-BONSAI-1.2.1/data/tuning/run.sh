#!/bin/bash
./create_like Cyl100.bin 0 > /dev/null
./create_like Cyl80.bin 1 > /dev/null
./create_like Cyl60.bin 2 > /dev/null
./create_like SK20BL.bin 3 > /dev/null
./create_like SK20PMT.bin 4 > /dev/null
./create_like SK12BL.bin 5 > /dev/null
./create_like HK20BL.bin 6 > /dev/null
./create_like HK20PMT.bin 7 > /dev/null
